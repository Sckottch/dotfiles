# SCG Doki Themes

Variações pessoais dos temas da Doki Theme (https://github.com/doki-theme/doki-theme-vscode, MIT), com cores semânticas extras para C#.

Para adicionar um tema novo: copie o JSON do tema original para `themes/`, ajuste `semanticTokenColors` e registre em `contributes.themes` no `package.json`.
